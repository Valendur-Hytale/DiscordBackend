﻿const config = require('config.json');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = require('_helpers/db');
const Application = db.Application;

module.exports = {
    getAllByUser,
    create,
    delete: _delete,
	deleteArray: _deleteArray,
	update
};


async function getAllByUser(userID) {
    return await Application.find({user: userID}).populate('risks').select('-user');
}

async function create(applicationParam, userID) {
    // validate
    if (await Application.findOne({ name: applicationParam.name, user: userID })) {
        throw 'The name "' + applicationParam.name + '" is already taken userID: ' + userID;;
    }
    const application = new Application(applicationParam);
	
	application.user = userID;
    await application.save();
}

async function update(applicationParam, userID) {
    const application = await Application.findOne({ _id: applicationParam._id, user: userID });

    // validate
    if (!application) throw 'Application not found';
    if (application.name !== applicationParam.name && await Application.findOne({ name: applicationParam.name,  user: userID })) {
        throw 'Username "' + applicationParam.name + '" is already taken';
    }

    // copy userParam properties to user
    Object.assign(application, applicationParam);

    await application.save();
}

async function _delete(id, userID) {
    await Application.deleteOne({_id: id, user: userID});
}

async function _deleteArray(jsonArray, userID) {
	//jsonArray.forEach(function(obj) { await Application.deleteOne({_id: obj._id, user: userID}); });
	for(var i = 0; i < jsonArray.length; i++) {
    	var obj = jsonArray[i];
    	await Application.deleteOne({_id: obj._id, user: userID});
	}
}