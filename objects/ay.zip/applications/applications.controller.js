﻿const express = require('express');
const router = express.Router();
const applicationService = require('./application.service');

// routes
router.post('/create', create);
router.get('/', getAllByUser);
//router.put('/:id', update);
router.delete('/:id', _delete);
router.post('/delete', _deleteArray);
router.put('/', update);

module.exports = router;


function create(req, res, next) {
    applicationService.create(req.body, req.user.sub)
        .then(() => res.json({}))
        .catch(err => next(err));
}

function getAllByUser(req, res, next) {
    applicationService.getAllByUser(req.user.sub)
        .then(applications => res.json(applications))
        .catch(err => next(err));
}


function update(req, res, next) {
    applicationService.update(req.body, req.user.sub)
        .then(() => res.json({}))
        .catch(err => next(err));
}

function _delete(req, res, next) {
    applicationService.delete(req.params.id, req.user.sub)
        .then(() => res.json({}))
        .catch(err => next(err));
}

function _deleteArray(req, res, next) {
    applicationService.deleteArray(req.body, req.user.sub)
        .then(() => res.json({}))
        .catch(err => next(err));
}