const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const db = require('_helpers/db');
const User = db.User;
const Risk = db.Risk;

const application = new Schema({
    name: { type: String, required: true },
    description: { type: String, required: false },
    risks: [{ type: Schema.Types.ObjectId, ref: 'Risk', required: false }],
    user: { type: Schema.Types.ObjectId, ref: 'User', required: false },
    createdDate: { type: Date, default: Date.now },
	endOfSupport: { type: Date, required: false },
	relevant: { type: Boolean, required: false },
	monthlyCosts: { type: Number, required: false },
	importanceLevel: { type: Number, required: false }
});

application.set('toJSON', { virtuals: true });





module.exports = mongoose.model('Application', application);